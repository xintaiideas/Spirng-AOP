package com.imooc.pattern;

/**
 * Created by cat on 2017-02-27.
 */
public interface Subject {
    void request();
    void hello();
}

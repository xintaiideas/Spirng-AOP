package com.imooc.bean;

import com.imooc.anno.NeedSecured;

/**
 * Created by cat on 2017-02-19.
 */
@NeedSecured
public class Product {
}
